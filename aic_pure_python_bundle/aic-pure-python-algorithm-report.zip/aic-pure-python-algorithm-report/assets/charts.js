(function () {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue("--accent").trim();
  var accent2 = style.getPropertyValue("--accent2").trim();
  var ink = style.getPropertyValue("--ink").trim();
  var muted = style.getPropertyValue("--muted").trim();
  var rule = style.getPropertyValue("--rule").trim();
  var bg2 = style.getPropertyValue("--bg2").trim();

  function axis() {
    return {
      axisLine: { lineStyle: { color: rule } },
      axisTick: { show: false },
      axisLabel: { color: muted, fontSize: 12 },
      splitLine: { lineStyle: { color: rule, opacity: 0.55 } },
    };
  }

  var timeChart = echarts.init(
    document.getElementById("chart-time-scales"),
    null,
    { renderer: "svg" }
  );
  timeChart.setOption({
    animation: false,
    tooltip: {
      trigger: "axis",
      appendToBody: true,
      valueFormatter: function (value) {
        return value + " samples";
      },
    },
    grid: { left: 54, right: 24, top: 26, bottom: 52 },
    xAxis: Object.assign({ type: "category", data: ["Host API", "Model hop", "FFT frame"] }, axis()),
    yAxis: Object.assign({ type: "value", name: "Samples", nameTextStyle: { color: muted } }, axis()),
    series: [
      {
        type: "bar",
        barMaxWidth: 54,
        data: [160, 240, 480],
        itemStyle: { color: accent, borderRadius: [3, 3, 0, 0] },
        label: { show: true, position: "top", color: ink, formatter: "{c}" },
      },
    ],
  });

  var performanceChart = echarts.init(
    document.getElementById("chart-performance"),
    null,
    { renderer: "svg" }
  );
  performanceChart.setOption({
    animation: false,
    tooltip: {
      trigger: "axis",
      appendToBody: true,
      valueFormatter: function (value) {
        return Number(value).toFixed(5) + " RTF";
      },
    },
    grid: { left: 54, right: 24, top: 26, bottom: 52 },
    xAxis: Object.assign({ type: "category", data: ["Pure Python", "Native dylib"] }, axis()),
    yAxis: Object.assign({ type: "value", name: "RTF", min: 0, max: 0.22, nameTextStyle: { color: muted } }, axis()),
    series: [
      {
        type: "bar",
        barMaxWidth: 64,
        data: [
          { value: 0.195728, itemStyle: { color: accent } },
          { value: 0.01834, itemStyle: { color: accent2 } },
        ],
        label: {
          show: true,
          position: "top",
          color: ink,
          formatter: function (params) {
            return Number(params.value).toFixed(3);
          },
        },
      },
    ],
  });

  var validationChart = echarts.init(
    document.getElementById("chart-validation"),
    null,
    { renderer: "svg" }
  );
  validationChart.setOption({
    animation: false,
    tooltip: {
      trigger: "axis",
      appendToBody: true,
      valueFormatter: function (value) {
        return value + " LSB";
      },
    },
    grid: { left: 58, right: 24, top: 26, bottom: 52 },
    xAxis: Object.assign(
      {
        type: "category",
        data: ["Raw Float32 max", "PCM16 max"],
      },
      axis()
    ),
    yAxis: Object.assign(
      { type: "value", name: "LSB", min: 0, max: 1.1, nameTextStyle: { color: muted } },
      axis()
    ),
    series: [
      {
        type: "bar",
        barMaxWidth: 64,
        data: [0.08837890625, 1],
        itemStyle: { color: accent2, borderRadius: [3, 3, 0, 0] },
        label: {
          show: true,
          position: "top",
          color: ink,
          formatter: function (params) {
            return params.value < 0.1 ? "<0.1" : String(params.value);
          },
        },
      },
    ],
  });

  window.addEventListener("resize", function () {
    timeChart.resize();
    performanceChart.resize();
    validationChart.resize();
  });
})();
