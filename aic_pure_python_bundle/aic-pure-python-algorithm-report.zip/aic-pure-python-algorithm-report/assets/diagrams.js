(function () {
  var style = getComputedStyle(document.documentElement);
  var bg2 = style.getPropertyValue("--bg2").trim();
  var ink = style.getPropertyValue("--ink").trim();
  var accent = style.getPropertyValue("--accent").trim();
  var accent2 = style.getPropertyValue("--accent2").trim();
  var muted = style.getPropertyValue("--muted").trim();
  var rule = style.getPropertyValue("--rule").trim();
  var softAccent = style.getPropertyValue("--soft-accent").trim();
  var softAccent2 = style.getPropertyValue("--soft-accent2").trim();
  mermaid.initialize({
    startOnLoad: true,
    securityLevel: "loose",
    theme: "base",
    themeVariables: {
      fontFamily: "Instrument Sans, sans-serif",
      primaryColor: bg2,
      primaryTextColor: ink,
      primaryBorderColor: accent,
      lineColor: muted,
      secondaryColor: softAccent2,
      secondaryTextColor: ink,
      tertiaryColor: bg2,
      tertiaryTextColor: ink,
      textColor: ink,
      clusterBkg: softAccent,
      clusterBorder: accent,
      titleColor: ink,
      labelBackground: softAccent,
      edgeLabelBackground: bg2,
    },
    flowchart: {
      curve: "basis",
      htmlLabels: true,
      nodeSpacing: 28,
      rankSpacing: 36,
    },
  });
})();
